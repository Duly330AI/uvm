from django.conf import settings
from django.contrib import admin
from django.http import JsonResponse
from django.urls import path
from landlord.views import (
    ChatConfirmView,
    ChatMessageView,
    ChatPageView,
    chat_session_create_plain,
)


def healthz_view(_request):
    # Lazy imports to avoid DB/Redis at import time
    from django.db import connections
    from django.db.utils import OperationalError

    db_ok = False
    try:
        with connections["default"].cursor() as cursor:
            cursor.execute("SELECT 1")
            cursor.fetchone()
            db_ok = True
    except OperationalError:
        db_ok = False

    redis_ok = False
    try:
        import redis

        r = redis.Redis.from_url(settings.REDIS_URL)
        r.ping()
        redis_ok = True
    except Exception:
        redis_ok = False

    return JsonResponse({"status": "ok", "db": db_ok, "redis": redis_ok})


def api_ping_view(_request):
    return JsonResponse({"pong": True})


urlpatterns = [
    path("admin/", admin.site.urls),
    path("healthz", healthz_view),
    path("api/ping/", api_ping_view),
    # Chat API
    path("chat/", ChatPageView.as_view()),
    # Plain Django view first to accept empty POST without parser 415s
    path("api/chat/sessions/", chat_session_create_plain),
    path("api/chat/sessions/<uuid:id>/message", ChatMessageView.as_view()),
    path("api/chat/sessions/<uuid:id>/confirm", ChatConfirmView.as_view()),
]
