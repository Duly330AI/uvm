
from .celery_app import celery_app as app  # noqa: F401

