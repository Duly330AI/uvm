from .base import *  # noqa
from . import base as _base
import os

DEBUG = False

# Set your production hosts via env DJANGO_ALLOWED_HOSTS (comma separated) or configure here
ALLOWED_HOSTS = os.getenv("DJANGO_ALLOWED_HOSTS", "").split(",") if os.getenv("DJANGO_ALLOWED_HOSTS") else []

# Security hardening placeholders
SECURE_SSL_REDIRECT = os.getenv("SECURE_SSL_REDIRECT", "true").lower() in {"1","true","yes"}
SESSION_COOKIE_SECURE = True
CSRF_COOKIE_SECURE = True
SECURE_HSTS_SECONDS = int(os.getenv("SECURE_HSTS_SECONDS", "3600"))
SECURE_HSTS_INCLUDE_SUBDOMAINS = True
SECURE_HSTS_PRELOAD = True

# During pytest runs, avoid HTTPS redirect to keep test client simple
if os.getenv("PYTEST_CURRENT_TEST"):
	SECURE_SSL_REDIRECT = False

# Reverse proxy/SSL settings (when behind a proxy)
SECURE_PROXY_SSL_HEADER = ("HTTP_X_FORWARDED_PROTO", "https") if os.getenv("SECURE_PROXY_SSL_HEADER", "true").lower() in {"1","true","yes"} else None

# CSRF trusted origins (comma separated), e.g. https://app.example.com,https://admin.example.com
_csrf = os.getenv("DJANGO_CSRF_TRUSTED_ORIGINS", "")
if _csrf:
	CSRF_TRUSTED_ORIGINS = [o.strip() for o in _csrf.split(",") if o.strip()]

# DRF: in prod nur JSON Renderer
REST_FRAMEWORK = {
	**_base.REST_FRAMEWORK,
	"DEFAULT_RENDERER_CLASSES": [
		"rest_framework.renderers.JSONRenderer",
	],
}

# Default cache uses Redis in production
CACHES = {
	"default": {
		"BACKEND": "django_redis.cache.RedisCache",
		"LOCATION": os.getenv("REDIS_URL", "redis://redis:6379/0"),
		"OPTIONS": {"CLIENT_CLASS": "django_redis.client.DefaultClient"},
		"TIMEOUT": 300,
	}
}
