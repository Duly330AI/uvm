from __future__ import annotations

from celery import shared_task
from django.conf import settings
from django.core.mail import EmailMultiAlternatives
from django.template.loader import render_to_string
from django.utils.html import strip_tags

from .models import Appointment, Issue
from .utils.ics import build_ics


def _plain_from_html(html: str) -> str:
    # Very simple plaintext fallback
    try:
        import re
        return re.sub(r"<[^>]+>", "", html)
    except Exception:
        return html


@shared_task(
    autoretry_for=(Exception,), retry_backoff=2, max_retries=5, acks_late=True, time_limit=30
)
def send_issue_created(issue_id: int) -> None:
    issue = Issue.objects.select_related("tenant", "unit").get(id=issue_id)
    subject = f"[{issue.ticket_no}] Meldung eingegangen"
    ctx = {
        "issue": issue,
        "site_domain": getattr(settings, "SITE_DOMAIN", "localhost"),
    }
    html = render_to_string("emails/issue_created.html", ctx)
    body = strip_tags(html) or _plain_from_html(html)
    to_email = [issue.tenant.primary_email] if issue.tenant and issue.tenant.primary_email else []
    if not to_email:
        return
    msg = EmailMultiAlternatives(subject=subject, body=body, from_email=settings.DEFAULT_FROM_EMAIL, to=to_email)
    msg.attach_alternative(html, "text/html")
    msg.send()


@shared_task(
    autoretry_for=(Exception,), retry_backoff=2, max_retries=5, acks_late=True, time_limit=30
)
def send_status_changed(issue_id: int, old: str, new: str) -> None:
    issue = Issue.objects.select_related("tenant").get(id=issue_id)
    subject = f"[{issue.ticket_no}] Status geändert: {old} → {new}"
    html = f"<p>Status geändert von <b>{old}</b> auf <b>{new}</b> für Ticket <b>{issue.ticket_no}</b>.</p>"
    body = strip_tags(html) or _plain_from_html(html)
    to_email = [issue.tenant.primary_email] if issue.tenant and issue.tenant.primary_email else []
    if not to_email:
        return
    msg = EmailMultiAlternatives(subject=subject, body=body, from_email=settings.DEFAULT_FROM_EMAIL, to=to_email)
    msg.attach_alternative(html, "text/html")
    msg.send()


@shared_task(
    autoretry_for=(Exception,), retry_backoff=2, max_retries=5, acks_late=True, time_limit=30
)
def send_appointment_invite(appointment_id: int) -> None:
    appt = Appointment.objects.select_related("issue__tenant", "vendor").get(id=appointment_id)
    issue = appt.issue
    subject = f"[{issue.ticket_no}] Terminvorschlag"
    to_email = [issue.tenant.primary_email] if issue.tenant and issue.tenant.primary_email else []
    if not to_email:
        return
    # Build ICS
    ics_bytes = build_ics(appt, getattr(settings, "SITE_DOMAIN", "localhost"))
    # Compose mail
    html = f"<p>Terminvorschlag für Ticket <b>{issue.ticket_no}</b>: {appt.start.isoformat()} – {appt.end.isoformat()}</p>"
    body = strip_tags(html) or _plain_from_html(html)
    msg = EmailMultiAlternatives(subject=subject, body=body, from_email=settings.DEFAULT_FROM_EMAIL, to=to_email)
    msg.attach_alternative(html, "text/html")
    msg.attach("appointment.ics", ics_bytes, "text/calendar; method=REQUEST; charset=UTF-8")
    # Optional Outlook header
    msg.extra_headers = {"Content-Class": "urn:content-classes:calendarmessage"}
    msg.send()
