from __future__ import annotations

import uuid

from django.conf import settings
from django.core.validators import MaxValueValidator, MinValueValidator
from django.db import models
from django.db.models import Q


class TimeStampedModel(models.Model):
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        abstract = True


class Property(TimeStampedModel):
    name = models.CharField(max_length=200, blank=True)
    street = models.CharField(max_length=200)
    postal_code = models.CharField(max_length=20)
    city = models.CharField(max_length=100)
    country = models.CharField(max_length=100, default="Deutschland")
    geo_lat = models.DecimalField(max_digits=9, decimal_places=6, null=True, blank=True)
    geo_lng = models.DecimalField(max_digits=9, decimal_places=6, null=True, blank=True)
    notes = models.TextField(blank=True)

    def __str__(self) -> str:  # pragma: no cover - display only
        return self.name or f"{self.street}, {self.postal_code} {self.city}"


class Unit(TimeStampedModel):
    property = models.ForeignKey(Property, on_delete=models.CASCADE, related_name="units")
    unit_label = models.CharField(max_length=100)
    floor = models.CharField(max_length=50, blank=True)
    rooms = models.PositiveSmallIntegerField(null=True, blank=True)
    area_sqm = models.DecimalField(max_digits=7, decimal_places=2, null=True, blank=True)
    notes = models.TextField(blank=True)
    is_active = models.BooleanField(default=True)

    class Meta:
        indexes = [
            models.Index(fields=["property", "unit_label"]),
        ]

    def __str__(self) -> str:  # pragma: no cover
        return f"{self.unit_label} @ {self.property}"


class Tenant(TimeStampedModel):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True)
    primary_email = models.EmailField()
    phone = models.CharField(max_length=50, blank=True)
    unit = models.ForeignKey(Unit, on_delete=models.PROTECT, related_name="tenants", db_index=True)
    moved_in_at = models.DateField(null=True, blank=True)
    moved_out_at = models.DateTimeField(null=True, blank=True)
    is_active = models.BooleanField(default=True)

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=["unit"],
                condition=Q(is_active=True, moved_out_at__isnull=True),
                name="uq_active_tenant_per_unit",
            )
        ]

    def __str__(self) -> str:  # pragma: no cover
        return self.primary_email


class Vendor(TimeStampedModel):
    name = models.CharField(max_length=200)
    email = models.EmailField(blank=True)
    phone = models.CharField(max_length=50, blank=True)
    trade = models.CharField(max_length=100, blank=True)
    address_text = models.TextField(blank=True)
    notes = models.TextField(blank=True)

    def __str__(self) -> str:  # pragma: no cover
        return self.name


class Issue(TimeStampedModel):
    class Category(models.TextChoices):
        WATER = "water", "Water"
        HEATING = "heating", "Heating"
        ELECTRICITY = "electricity", "Electricity"
        STRUCTURAL = "structural", "Structural"
        OTHER = "other", "Other"

    class Status(models.TextChoices):
        NEW = "NEW", "New"
        IN_PROGRESS = "IN_PROGRESS", "In progress"
        WAITING_TENANT = "WAITING_TENANT", "Waiting tenant"
        WAITING_VENDOR = "WAITING_VENDOR", "Waiting vendor"
        SCHEDULED = "SCHEDULED", "Scheduled"
        RESOLVED = "RESOLVED", "Resolved"
        CANCELLED = "CANCELLED", "Cancelled"

    ticket_no = models.CharField(max_length=32, null=True, blank=True, unique=True)
    tenant = models.ForeignKey(Tenant, on_delete=models.SET_NULL, null=True, blank=True, related_name="issues")
    unit = models.ForeignKey(Unit, on_delete=models.PROTECT, related_name="issues", null=True, blank=True)
    category = models.CharField(max_length=20, choices=Category.choices, default=Category.OTHER)
    severity = models.PositiveSmallIntegerField(default=3, validators=[MinValueValidator(1), MaxValueValidator(5)])
    status = models.CharField(max_length=20, choices=Status.choices, default=Status.NEW, db_index=True)
    summary = models.CharField(max_length=255)
    description_raw = models.TextField(blank=True)
    description_struct = models.JSONField(default=dict, blank=True)
    occurred_at = models.DateTimeField(null=True, blank=True)
    location_hint = models.CharField(max_length=200, blank=True)
    contact_times = models.CharField(max_length=200, blank=True)
    sla_due_at = models.DateTimeField(null=True, blank=True)
    created_via = models.CharField(max_length=20, default="chat")

    class Meta:
        constraints = [
            models.CheckConstraint(
                check=Q(tenant__isnull=False) | Q(unit__isnull=False),
                name="ck_issue_has_tenant_or_unit",
            )
        ]
        indexes = [
            models.Index(fields=["status", "-created_at"]),
            models.Index(fields=["tenant", "unit"]),
            models.Index(fields=["created_at"]),
        ]
        ordering = ["-created_at"]

    def __str__(self) -> str:  # pragma: no cover
        return f"#{self.pk or 'NEW'} {self.summary[:40]}"


class IssueAttachment(TimeStampedModel):
    class UploaderRole(models.TextChoices):
        TENANT = "tenant", "Tenant"
        STAFF = "staff", "Staff"

    issue = models.ForeignKey(Issue, on_delete=models.CASCADE, related_name="attachments")
    file = models.FileField(upload_to="issues/%Y/%m/%d/")
    mime = models.CharField(max_length=100, blank=True)
    size_bytes = models.PositiveIntegerField(null=True, blank=True)
    uploader_role = models.CharField(max_length=10, choices=UploaderRole.choices, default=UploaderRole.TENANT)


class IssueNote(TimeStampedModel):
    class Visibility(models.TextChoices):
        INTERNAL = "internal", "Internal"
        PUBLIC = "public", "Public"

    issue = models.ForeignKey(Issue, on_delete=models.CASCADE, related_name="notes")
    author = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True)
    visibility = models.CharField(max_length=10, choices=Visibility.choices, default=Visibility.INTERNAL)
    text = models.TextField()


class Appointment(TimeStampedModel):
    class Status(models.TextChoices):
        INVITED = "invited", "Invited"
        CONFIRMED = "confirmed", "Confirmed"
        DONE = "done", "Done"
        CANCELLED = "cancelled", "Cancelled"

    issue = models.ForeignKey(Issue, on_delete=models.CASCADE, related_name="appointments")
    vendor = models.ForeignKey(Vendor, on_delete=models.PROTECT, related_name="appointments")
    start = models.DateTimeField()
    end = models.DateTimeField()
    status = models.CharField(max_length=10, choices=Status.choices, default=Status.INVITED)
    notes = models.TextField(blank=True)


class ChatSession(TimeStampedModel):
    class State(models.TextChoices):
        GREETING = "GREETING", "GREETING"
        CAPTURE_SUMMARY = "CAPTURE_SUMMARY", "CAPTURE_SUMMARY"
        CAPTURE_OCCURRED_AT = "CAPTURE_OCCURRED_AT", "CAPTURE_OCCURRED_AT"
        CAPTURE_LOCATION = "CAPTURE_LOCATION", "CAPTURE_LOCATION"
        CAPTURE_SEVERITY = "CAPTURE_SEVERITY", "CAPTURE_SEVERITY"
        CAPTURE_MEDIA = "CAPTURE_MEDIA", "CAPTURE_MEDIA"
        CAPTURE_CONTACT = "CAPTURE_CONTACT", "CAPTURE_CONTACT"
        CONFIRM = "CONFIRM", "CONFIRM"
        CREATE_ISSUE = "CREATE_ISSUE", "CREATE_ISSUE"
        DONE = "DONE", "DONE"

    id = models.UUIDField(primary_key=True, editable=False, default=uuid.uuid4)
    version = models.PositiveIntegerField(default=0)
    tenant = models.ForeignKey(Tenant, on_delete=models.SET_NULL, null=True, blank=True, related_name="chat_sessions")
    unit = models.ForeignKey(Unit, on_delete=models.SET_NULL, null=True, blank=True, related_name="chat_sessions")
    state = models.CharField(max_length=40, choices=State.choices, default=State.GREETING)
    payload = models.JSONField(default=dict, blank=True)
    transcript = models.JSONField(default=list, blank=True)
    expires_at = models.DateTimeField(null=True, blank=True)
    issue = models.OneToOneField(
        "landlord.Issue",
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="chat_session",
    )

    class Meta:
        indexes = [
            models.Index(fields=["expires_at"]),
        ]


class IdempotencyKey(TimeStampedModel):
    key = models.UUIDField()
    scope = models.CharField(max_length=50)
    session = models.ForeignKey(ChatSession, on_delete=models.CASCADE, related_name="idempotency_keys")
    issue = models.ForeignKey(Issue, null=True, blank=True, on_delete=models.SET_NULL)

    class Meta:
        constraints = [
            models.UniqueConstraint(fields=["key", "scope"], name="uq_idempotency_key_scope")
        ]

