from datetime import timedelta

from django.contrib import admin, messages
from django.db import transaction
from django.utils import timezone

from . import models


class IssueNoteInline(admin.TabularInline):
	model = models.IssueNote
	extra = 0


class IssueAttachmentInline(admin.TabularInline):
	model = models.IssueAttachment
	extra = 0


class AppointmentInline(admin.TabularInline):
	model = models.Appointment
	extra = 0


@admin.register(models.Property)
class PropertyAdmin(admin.ModelAdmin):
	list_display = ("id", "name", "street", "postal_code", "city", "created_at")
	search_fields = ("name", "street", "postal_code", "city")
	list_filter = ("city",)


@admin.register(models.Unit)
class UnitAdmin(admin.ModelAdmin):
	list_display = ("id", "property", "unit_label", "is_active", "created_at")
	search_fields = ("unit_label", "property__street", "property__city")
	list_filter = ("is_active", "property")


@admin.register(models.Tenant)
class TenantAdmin(admin.ModelAdmin):
	list_display = ("id", "primary_email", "phone", "unit", "is_active", "created_at")
	search_fields = ("primary_email", "phone", "unit__unit_label")
	list_filter = ("is_active",)


@admin.register(models.Vendor)
class VendorAdmin(admin.ModelAdmin):
	list_display = ("id", "name", "email", "phone", "trade")
	search_fields = ("name", "email", "trade")
	list_filter = ("trade",)


@admin.register(models.Issue)
class IssueAdmin(admin.ModelAdmin):
	list_display = ("ticket_no", "status", "category", "severity", "unit", "tenant", "created_at")
	list_filter = ("status", "category", "severity", "unit__property")
	search_fields = (
		"ticket_no",
		"summary",
		"tenant__user__email",
		"tenant__user__first_name",
		"tenant__user__last_name",
	)
	date_hierarchy = "created_at"
	inlines = [IssueNoteInline, IssueAttachmentInline, AppointmentInline]
	actions = ("mark_in_progress", "assign_vendor_krach",)

	@admin.action(description="Status: In Arbeit setzen")
	def mark_in_progress(self, request, queryset):
		from .services.issues import update_status
		with transaction.atomic():
			for issue in queryset:
				update_status(issue, models.Issue.Status.IN_PROGRESS)

	@admin.action(description="Vendor Krach zuweisen (+ Termin +2d/1h)")
	def assign_vendor_krach(self, request, queryset):
		# pick or create a demo vendor "Krach"
		vendor, _ = models.Vendor.objects.get_or_create(name="Krach", defaults={"trade": "Sanitär"})
		in_two_days = timezone.now() + timedelta(days=2)
		with transaction.atomic():
			for issue in queryset:
				start = in_two_days
				end = start + timedelta(hours=1)
				appt = models.Appointment.objects.create(issue=issue, vendor=vendor, start=start, end=end)
				issue.status = models.Issue.Status.WAITING_VENDOR
				issue.save(update_fields=["status", "updated_at"])
		try:
			from .tasks import send_appointment_invite
			for issue in queryset:
				appt = issue.appointments.order_by("-created_at").first()
				if appt:
					send_appointment_invite.delay(appt.id)
		except Exception:
			messages.warning(request, "Termin-Mail konnte nicht enqueued werden.")


@admin.register(models.IssueAttachment)
class IssueAttachmentAdmin(admin.ModelAdmin):
	list_display = ("id", "issue", "mime", "size_bytes", "uploader_role", "created_at")
	list_filter = ("uploader_role",)


@admin.register(models.IssueNote)
class IssueNoteAdmin(admin.ModelAdmin):
	list_display = ("id", "issue", "author", "visibility", "created_at")
	list_filter = ("visibility",)
	search_fields = ("text",)


@admin.register(models.Appointment)
class AppointmentAdmin(admin.ModelAdmin):
	list_display = ("id", "issue", "vendor", "start", "end", "status")
	list_filter = ("status", "vendor")
	date_hierarchy = "start"

